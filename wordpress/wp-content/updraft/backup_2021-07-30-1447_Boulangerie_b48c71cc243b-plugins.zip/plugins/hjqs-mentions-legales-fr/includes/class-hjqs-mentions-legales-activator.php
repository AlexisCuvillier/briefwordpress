<?php

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Hjqs_Mentions_Legales
 * @subpackage Hjqs_Mentions_Legales/includes
 * @author     Your Name <email@example.com>
 */
class Hjqs_Mentions_Legales_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
