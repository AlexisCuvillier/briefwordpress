<?php
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Hjqs_Mentions_Legales
 * @subpackage Hjqs_Mentions_Legales/includes
 * @author     Your Name <email@example.com>
 */
class Hjqs_Mentions_Legales_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
